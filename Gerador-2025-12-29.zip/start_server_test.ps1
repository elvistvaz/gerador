Set-Location "c:\java\workspace\Gerador\generated\icep-laravel"
& "C:\php82\php.exe" artisan serve --port=8000
