cd "c:\java\workspace\Gerador\generated\xandel-laravel"
C:\php82\php.exe artisan serve --port=8888
