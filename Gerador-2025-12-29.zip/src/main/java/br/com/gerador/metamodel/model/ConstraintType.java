package br.com.gerador.metamodel.model;

/**
 * Tipos de constraints de banco de dados.
 */
public enum ConstraintType {
    CHECK,
    UNIQUE,
    DEFAULT
}
